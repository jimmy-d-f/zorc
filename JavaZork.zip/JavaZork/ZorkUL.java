public class ZorkUL {
    public static final String WELCOME_MESSAGE = "Welcome to the ZorkUL Game!";
    public static final String VERSION = "1.0";
}